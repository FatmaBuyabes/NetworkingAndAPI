//
//  Enums.swift
//  NetworkingandAPI
//
//  Created by Fatma Buyabes on 05/03/2024.
//

import Foundation

enum Tags {
    case name
    case gender
    case adopt
    case age
    case image
    
    func TagsString() -> String{
        switch self{
        
        case .name:return "Name"
        case .gender: return "Gender"
        case .age: return "Age"
        case .adopt: return "Adopt"
        case .image:return "URL"
        }
    }
}
