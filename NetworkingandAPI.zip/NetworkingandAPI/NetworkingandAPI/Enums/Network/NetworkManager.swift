//
//  NetworkManager.swift
//  NetworkingandAPI
//
//  Created by Fatma Buyabes on 04/03/2024.
//

import Foundation
import Alamofire

class NetworkManager{
    
    let baseURL = "https://coded-pets-api-crud.eapi.joincoded.com/pets" //endpoint
    
    
    // MARK: Singelton
    static let shared = NetworkManager()
    
    //MARK: HTTP Methods
    
    func fetchPets(completion: @escaping ([Pet]?) -> Void ){
    
        AF.request(baseURL).responseDecodable(of: [Pet].self){ response in
            switch response.result{
            case .success(let pet):
                completion(pet)
            case .failure(let error):
                completion(nil)
                print(error)
            
            }
        }
    }
    
    func deletePet(petID: Int, completion: @escaping (Bool) -> Void) { //Int for the backend
        AF.request("\(baseURL)/\(petID)", method: .delete).response { response in
            switch response.result {
            case .success:
                completion(true)
            case .failure(let error):
                print("Error occurred while deleting the book: \(error.localizedDescription)")
                completion(false)
            }
        }
    }
    
    
    // completion to check if pet is added or no
    func addPet(pet: Pet, completion: @escaping (Bool) -> Void){
        AF.request(baseURL,method: .post,parameters: pet,encoder: JSONParameterEncoder.default).response { response in
            switch response.result {
            
            case .success(_):
                completion(true)
                
            case .failure(let error):
                completion(false)
                print(error)
            }
            
        }
    }
}

