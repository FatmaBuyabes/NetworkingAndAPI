//
//  DetailPetViewController.swift
//  NetworkingandAPI
//
//  Created by Fatma Buyabes on 04/03/2024.
//

import UIKit
import SnapKit
import Kingfisher

class DetailPetViewController: UIViewController {
   
    var pet: Pet?
    
    private let petNameLabel = UILabel()
    private let containerView = UIView()
    private let petIdLabel = UILabel()
    private let petGenderLabel = UILabel()
    private let petAdoptedLabel = UILabel()
    private let petAgeLabel = UILabel()
    private let petImageLabel = UIImageView()
    var nameLabel = UILabel()
    var ageLabel = UILabel()
    var genderLabel = UILabel()
    var idLabel = UILabel()
    var adoptLabel = UILabel()

    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Pet Details View"
        view.backgroundColor = .white
        view.addSubview(containerView)
        view.addSubview(petNameLabel)
        view.addSubview(petAdoptedLabel)
        view.addSubview(petAgeLabel)
        view.addSubview(petIdLabel)
        view.addSubview(petImageLabel)
        view.addSubview(nameLabel)
        view.addSubview(ageLabel)
        view.addSubview(genderLabel)
        view.addSubview(idLabel)
        view.addSubview(adoptLabel)
        containerView.addSubview(petNameLabel)
        containerView.addSubview(petAgeLabel)
        containerView.addSubview(petIdLabel)
        containerView.addSubview(petImageLabel)
        containerView.addSubview(petGenderLabel)
        containerView.addSubview(nameLabel)
        containerView.addSubview(ageLabel)
        containerView.addSubview(adoptLabel)
        containerView.addSubview(genderLabel)
        containerView.addSubview(idLabel)
        configureWithPet()
        setupUI()
        setupLayout()
        setUpNavigationBar()

        // Do any additional setup after loading the view.
    }
    
    func setupUI(){
        
        containerView.backgroundColor = .darkGray
        containerView.layer.cornerRadius = 20
        
        petNameLabel.font = .systemFont(ofSize: 20, weight: .light)
        petNameLabel.textColor = .white
        
        petGenderLabel.font = .systemFont(ofSize: 20, weight: .light)
        petGenderLabel.textColor = .white
        
        petIdLabel.font = .systemFont(ofSize: 20, weight: .light)
        petIdLabel.textColor = .white

        petAgeLabel.font = .systemFont(ofSize: 20, weight: .light)
        petAgeLabel.textColor = .white

        petAdoptedLabel.font = .systemFont(ofSize: 20, weight: .light)
        petAdoptedLabel.textColor = .white
        
        nameLabel.text = "Name:"
        nameLabel.font = .systemFont(ofSize: 20, weight: .bold)
        nameLabel.textColor = .white
        
        genderLabel.text = "Gendar: "
        genderLabel.font = .systemFont(ofSize: 20, weight: .bold)
        genderLabel.textColor = .white
        
        idLabel.text = "ID:"
        idLabel.font = .systemFont(ofSize: 21, weight: .bold)
        idLabel.textColor = .white
        
        adoptLabel.text = "Adoption: "
        adoptLabel.font = .systemFont(ofSize: 21, weight: .bold)
        adoptLabel.textColor = .white
        
        ageLabel.text = "Age: "
        ageLabel.font = .systemFont(ofSize: 21, weight: .bold)
        ageLabel.textColor = .white
        
        petImageLabel.layer.cornerRadius = 40
        petImageLabel.contentMode = .scaleAspectFit
        petImageLabel.clipsToBounds = true
        
        
        
    }
    
    func setupLayout(){
        containerView.snp.makeConstraints { make in
            make.top.equalTo(view.safeAreaLayoutGuide).offset(20)
                make.leading.trailing.equalToSuperview().inset(20)
                make.height.equalTo(300)
            }
            
            petImageLabel.snp.makeConstraints { make in
                make.width.height.equalTo(100)
                make.centerX.equalTo(containerView).offset(-100)
                //.centerY.equalTo(containerView.snp.centerY).offset(40)
            }

            petNameLabel.snp.makeConstraints { make in
                make.leading.equalTo(petImageLabel.snp.leading).offset(100)
                //make.leading.equalTo(containerView.snp.leading).offset(100)
                make.bottom.equalTo(petImageLabel.snp.bottom).offset(40)
                
                //make.centerX.equalTo(containerView).offset(50)
                //make.leading.equalTo(petImageLabel.snp.leading).offset(20)
            }

            petGenderLabel.snp.makeConstraints { make in
                make.top.equalTo(petNameLabel.snp.bottom).offset(10)
                make.centerX.equalTo(genderLabel).offset(60)
            }

            petAdoptedLabel.snp.makeConstraints { make in
                make.top.equalTo(petGenderLabel.snp.bottom).offset(10)
                make.centerX.equalTo(adoptLabel).offset(70)
            }

            petAgeLabel.snp.makeConstraints { make in
                make.top.equalTo(petAdoptedLabel.snp.bottom).offset(10)
                make.centerX.equalTo(ageLabel).offset(40)        }

            petIdLabel.snp.makeConstraints { make in
                make.top.equalTo(petAgeLabel.snp.bottom).offset(10)
                make.centerX.equalTo(idLabel).offset(40 )
            }

            // Labels
            nameLabel.snp.makeConstraints { make in
                make.centerY.equalTo(petNameLabel)
                make.trailing.equalTo(petNameLabel.snp.leading).offset(-17)
            }

            genderLabel.snp.makeConstraints { make in
                make.centerY.equalTo(petGenderLabel)
                make.trailing.equalTo(petNameLabel.snp.leading)
            }

            adoptLabel.snp.makeConstraints { make in
                make.centerY.equalTo(petAdoptedLabel)
                make.trailing.equalTo(petNameLabel.snp.leading).offset(22)
            }

            ageLabel.snp.makeConstraints { make in
                make.centerY.equalTo(petAgeLabel)
                make.trailing.equalTo(petNameLabel.snp.leading).offset(-28)
            }

            idLabel.snp.makeConstraints { make in
                make.centerY.equalTo(petIdLabel)
                make.trailing.equalTo(petNameLabel.snp.leading).offset(-50)
            }
        }
    func setUpNavigationBar(){
        let appearance = UINavigationBarAppearance()
        appearance.configureWithOpaqueBackground()
        navigationController?.navigationBar.scrollEdgeAppearance = appearance
    }
        
        
            
    
    //let url = URL(string: "")
    //imageView.kf.setImage(with: url)
  
    func configureWithPet(){
        petNameLabel.text = pet?.name
        petGenderLabel.text = pet?.gender
        petAgeLabel.text = "\(pet?.age ?? 0)"
        petIdLabel.text = "\(pet?.id ?? 0)"
        
        //help by awdhah 🤍
        if let pets = pet, pet?.adopted == true {
            petAdoptedLabel.text = "Yes"
        } else  {
            petAdoptedLabel.text = "No"
        }
        
        petImageLabel.kf.setImage(with: URL(string: pet?.image ?? ""))
        
    }
    

}
