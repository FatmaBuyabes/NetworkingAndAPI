//
//  ViewController.swift
//  NetworkingandAPI
//
//  Created by Fatma Buyabes on 04/03/2024.
//

import UIKit
import Alamofire

class PetTableViewController: UITableViewController {

    var pets: [Pet] = []
    let saveButton = UIButton(type: .custom)

    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        view.addSubview(saveButton)
        title = "Pet List "
        
        tableView.register(UITableViewCell.self, forCellReuseIdentifier: "cell")
        setupNavigationBar()
        fetchPetData()
        
    }

    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return pets.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        let pet = pets[indexPath.row]
        
        cell.textLabel?.text = pet.name
        
        return cell
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let petVC = DetailPetViewController()
        let selectedPet = pets[indexPath.row]
        
        petVC.pet = selectedPet
        
        navigationController?.pushViewController(petVC, animated: true)
    }
    
    //MARK: Done by Omar
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 90
    }
    
    func setupNavigationBar() {
        navigationItem.rightBarButtonItem = UIBarButtonItem(
            image: UIImage(systemName: "plus.app"),
            style: .plain,
            target: self,
            action: #selector(navPet)
        )
        navigationItem.rightBarButtonItem?.tintColor = UIColor.blue
        
    }
    
    
    @objc func navPet(){
        let addPetVC = UINavigationController(rootViewController: AddPetViewController())
        addPetVC.modalPresentationStyle = .popover
        self.present(addPetVC, animated: true)
        
    }

    
    
    func fetchPetData(){ // i only want to call it
        NetworkManager.shared.fetchPets { fetchPets in
            DispatchQueue.main.async {
                self.pets = fetchPets ?? []
                self.tableView.reloadData()
            }
        }
    }
    
    
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            let petToDelete = pets[indexPath.row]  //here for the row index to save it
            NetworkManager.shared.deletePet(petID: petToDelete.id!) { [weak self] success in
                DispatchQueue.main.async {
                    if success {
                        // Remove the pet from the frontend
                        self?.pets.remove(at: indexPath.row)
                        // Delete the table view row
                        tableView.deleteRows(at: [indexPath], with: .fade)
                    } else {
                        // Handle the case where the book couldn't be deleted (e.g., show an alert)
                        print("print Nothing happened")
                    }
                }
            }
        }
    }
    
    
    

}

