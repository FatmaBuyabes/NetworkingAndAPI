//
//  AddPetViewController.swift
//  NetworkingandAPI
//
//  Created by Fatma Buyabes on 05/03/2024.
//

import UIKit
import Eureka

class AddPetViewController: FormViewController {

    let name = Tags.name
    let age = Tags.age
    let adopt = Tags.adopt
    let gender = Tags.gender
    let image = Tags.image
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupform()
        
        navigationItem.rightBarButtonItem = UIBarButtonItem(barButtonSystemItem: .add, target: self, action: #selector(AddPetAction))
        
    }
    
    func setupUI(){
        //let url = URl
        //imageView.kf.setImage(with: URL)
        
    }
        
        
    func setupform(){
        
        form +++ Section("Add Pet ")
        <<< TextRow() { row in
            row.title = " Pet Name "
            row.placeholder = "Enter Pet Name"
            row.tag = name.TagsString()
            row.add(rule: RuleRequired())
            row.validationOptions = .validatesOnChange
            
            row.cellUpdate { cell, row in
                if !row.isValid {
                    cell.titleLabel?.textColor = .red
                }
                
            }
            
        }
        <<< IntRow() { row in
            row.title = " Age "
            row.placeholder = "Enter Pet Age"
            row.tag = age.TagsString()
            row.add(rule: RuleRequired())
            row.validationOptions = .validatesOnChange
            }
            
        
            <<< ActionSheetRow<String>() { row in
                row.title = "Gender"
                row.selectorTitle = "Select The Gender"
                row.options = ["Female","Male"]
                row.tag = gender.TagsString()
                
            }
            
            
            <<< ActionSheetRow<String>() { row in
                row.title = "Adoption"
                row.selectorTitle = "Adoption Status"
                row.options = ["Yes","No"]
                row.tag = adopt.TagsString()
                
            }
            
            
            
            <<< URLRow() { row in
                row.title = " image "
                row.placeholder = " enter URL Image "
                row.tag = image.TagsString()
                
            }
            
            form +++ Section("")
            form +++ Section("")
            <<< ButtonRow(){ row in
                row.title = "Add Pet"
                
                row.onCellSelection{ cell, row in
                    print("Button Cell Tapped")
                    self.AddPetAction()
                    
                }
            }
        }
    
    func stringToBool(_ str: String) -> Bool?{
            let lowerCased = str.lowercased()
            if lowerCased == "yes"{
                return true
            }else if lowerCased == "no"{
                return false
            }
            else{
                return nil
            }
        }
    
    @objc func AddPetAction(){
        
        let errors = form.validate()
        
        guard errors.isEmpty else {
            print(errors)
            print("SOMETHING IS MISSING 🚨")

            presentAlertWithTitle(title: "🚨", message: "fill the empty textfields ")
            return
        }
        
        
        
        
        let nameRow: TextRow? = form.rowBy(tag: "Name")  //make enum for tags
        let urlRow: URLRow? = form.rowBy(tag: "URL")
        let ageRow: IntRow? = form.rowBy(tag: "Age")
        let genderRow: RowOf<String>! = form.rowBy(tag: "Gender")
        let adoptRow: RowOf<String>! = form.rowBy(tag: "Adopt")
        
        
        // Converting data to String,Int, and etc
        let name = nameRow?.value ?? ""
        let image = urlRow?.value?.absoluteString ?? ""
        let age = ageRow?.value ?? 0
        let gender = genderRow.value ?? ""
        let adopt = adoptRow.value ?? ""
        

        
        
        if let adopt = stringToBool(adopt){
            let pet = Pet(name: name, adopted: adopt, image: image, age: age, gender: gender)
            
            NetworkManager.shared.addPet(pet: pet) { success in
                
                DispatchQueue.main.async{
                    if success {
                        self.dismiss(animated: true, completion: nil)
                        
                        
                    }else{
                        print("Something went Wrong ")
                    }
                }
                
            }
        }
        
        
        // print(title)
        
        //let pet = Pet
    }
    
    
    private func presentAlertWithTitle(title: String, message: String) {
    let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
    alert.addAction(UIAlertAction(title: "OK", style: .default))
        self.present(alert, animated: true, completion: nil)
    }
        
        
    /// help by fatma
    @objc private func addPetTapped() {
                let navigationController = UINavigationController(rootViewController: AddPetViewController())
                present(navigationController, animated: true, completion: nil)
            }
        
    }
        


                               

