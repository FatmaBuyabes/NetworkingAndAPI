//
//  Pet.swift
//  NetworkingandAPI
//
//  Created by Fatma Buyabes on 04/03/2024.
//

import Foundation
import Alamofire

struct Pet: Codable {
    
    var id:Int? = 0
    var name: String
    var adopted: Bool
    var image: String
    var age: Int
    var gender: String
    
}


